import math

resultado = math.floor(3.54789524)
print(resultado)

resultado = math.ceil(3.54789852)
print(resultado)

resultado = math.log(25,5)
print(resultado)

resultado = math.tan(25)
print(resultado)

resultado1 = math.sqrt(math.pi)
print(resultado1)

resultado2 = math.factorial(7)
print(resultado2)