import shutil


# vamos a mover el archivo creado

shutil.move('curso.txt','C:\\Users\\Usuario\\Documents\\software\\Python\\Dia8')


'''
    shutil.rmtree ---> borra todo, pero cuidado.... (no va a la papelera de reciclaje
'''

