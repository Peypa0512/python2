import datetime
from datetime import datetime
'''
mi_hora = datetime.time(17,35)

print(type(mi_hora))
print(mi_hora.minute)
print(mi_hora.hour)


mi_fecha = datetime.date(2025,10,17)

print(mi_fecha.year)
print(mi_fecha.ctime())
print(mi_fecha.today())

#combinamos fecha y hora

mi_anuario = datetime(2025,5,12,17,33,5)

mi_anuario = mi_anuario.replace(month = 11)
print(mi_anuario)


nacimiento = date(1949,9,25)
defuncion = date (2022,9,16)

vida = defuncion - nacimiento

print(vida.days)

despierta = datetime(2022,10,5,7,30)
dormido = datetime(2022,10,5,23,45)

vigilia = dormido - despierta

print(vigilia)
print(vigilia.seconds)


fecha = date.today()

print(fecha)
'''
minutos = datetime.now().minute
print(minutos)
